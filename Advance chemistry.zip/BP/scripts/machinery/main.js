// ============================================================
// Age of Chemical — Machines
// ============================================================
import "./singleblock/liquifier.js";
import "./singleblock/fuel_mixer.js";
import "./singleblock/chemical_reactor.js";
import "./singleblock/separator.js";
import "./singleblock/polymerizer.js";
import "./singleblock/relic_synthesizer.js";
import "./singleblock/industrial_crusher.js";

//multiblock
import "./multiblock/index.js";
